g++ -std=c++11 -o offline2.out router_1305002.cpp
./offline2.out 192.168.10.1 topo.txt
